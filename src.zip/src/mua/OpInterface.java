package mua;

public interface OpInterface {
    public int getOpNum();

    public String calc(Value[] args, NameSpace n);
}

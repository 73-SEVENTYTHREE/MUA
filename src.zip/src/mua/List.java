package mua;

public class List<T> {

}
